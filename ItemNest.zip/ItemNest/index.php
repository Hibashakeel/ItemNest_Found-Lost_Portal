<?php include "config.php"; ?>
<?php include "includes/header.php"; ?>

<div class="home">
  <h1>Welcome to <b>ItemNest</b></h1>
  <p>A smarter way to manage Lost and Found items.</p>
  <a href="pages/login.php" class="btn">Get Started</a>
</div>
<!-- Floating Shapes -->
  <div class="floating-shapes">
    <span class="shape shape1"></span>
    <span class="shape shape2"></span>
    <span class="shape shape3"></span>
    <span class="shape shape4"></span>
  </div>
<?php include "includes/footer.php"; ?>
