<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>ItemNest</title>
  <!-- <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css"> -->
  <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css?v=<?php echo time(); ?>">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

</head>
<body>
<?php include "navbar.php"; ?>
