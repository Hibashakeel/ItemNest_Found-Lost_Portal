<footer>
  <p>© 2025 ItemNest — Lost & Found Management System</p>
</footer>
</body>
</html>
